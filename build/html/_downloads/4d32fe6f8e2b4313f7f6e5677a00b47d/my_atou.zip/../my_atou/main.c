#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

unsigned int my_atou_naive(const char *number);
unsigned int my_atou_better_loop(const char *number);
unsigned int my_atou_no_mul(const char *number);
unsigned int my_atou_lea(const char *number);
unsigned int my_atou(const char *number);

#define MAX_NUM_LENGTH 11 // Unsigned arrive jusqu'à 4 294 967 295, on a besoin de 10 chiffres + 0 de terminaison
#define BIG_VALUE_MIN 1000000

void generate_random_number_string(char *buffer, char bigValuesOnly)
{
    unsigned int num = (unsigned int)rand();
    if (bigValuesOnly)
    {
        while (num < BIG_VALUE_MIN)
            num = (unsigned int)rand();
    }
    sprintf(buffer, "%u", num);
}

int main(int argc, char **argv)
{
    if (argc != 3)
    {
        printf("Usage: %s <number_of_iterations> <bigNumberOnly>\n", argv[0]);
        return -1;
    }

    srand(0); // pour avoir les même valeurs à chaque execution

    int iterations = atoi(argv[1]);
    char number_buffer[MAX_NUM_LENGTH];

    unsigned int results[6];
    clock_t start_time, end_time;
    double total_times[6] = {0};

    char bigValuesOnly = atoi(argv[2]);

    printf("Starting stress test with %d iterations...\n\n", iterations);

    for (int i = 0; i < iterations; i++)
    {
        generate_random_number_string(number_buffer,bigValuesOnly);

        start_time = clock();
        results[0] = atoi(number_buffer);
        end_time = clock();
        total_times[0] += ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

        start_time = clock();
        results[1] = my_atou_naive(number_buffer);
        end_time = clock();
        total_times[1] += ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

        start_time = clock();
        results[2] = my_atou_better_loop(number_buffer);
        end_time = clock();
        total_times[2] += ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

        start_time = clock();
        results[3] = my_atou_no_mul(number_buffer);
        end_time = clock();
        total_times[3] += ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

        start_time = clock();
        results[4] = my_atou_lea(number_buffer);
        end_time = clock();
        total_times[4] += ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

        start_time = clock();
        results[5] = my_atou(number_buffer);
        end_time = clock();
        total_times[5] += ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

        // Verification
        if (!(results[0] == results[1] && results[1] == results[2] && results[2] == results[3] && results[3] == (unsigned)results[4] && results[3] == results[5]))
        {
            printf("Error: Implementations gave different results for input %s:\n", number_buffer);
            printf("glibc: %u\n", results[0]);
            printf("naive: %u\n", results[1]);
            printf("better_loop: %u\n", results[2]);
            printf("no_mul: %u\n", results[3]);
            printf("lea: %u\n", results[4]);
            printf("my_atou: %u\n", results[5]);
            return -1;
        }
    }

    // Print timing results
    printf("\nTest completed successfully! All implementations gave matching results.\n");
    printf("\nTiming results:\n");
    printf("glibc:       %.6f seconds (avg: %.9f)\n", total_times[0], total_times[0] / iterations);
    printf("naive:       %.6f seconds (avg: %.9f)\n", total_times[1], total_times[1] / iterations);
    printf("better_loop: %.6f seconds (avg: %.9f)\n", total_times[2], total_times[2] / iterations);
    printf("no_mul:      %.6f seconds (avg: %.9f)\n", total_times[3], total_times[3] / iterations);
    printf("lea:         %.6f seconds (avg: %.9f)\n", total_times[4], total_times[4] / iterations);
    printf("my_atou:     %.6f seconds (avg: %.9f)\n", total_times[5], total_times[5] / iterations);

    return 0;
}
